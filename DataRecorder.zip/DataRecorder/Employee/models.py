from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse

# Create your models here.
# here we create fields
class Post(models.Model):
	empId = models.IntegerField()
	firstname = models.CharField(max_length=20)
	lastname = models.CharField(max_length=20)
	dob = models.DateField()
	address = models.CharField(max_length=20)
	city = models.CharField(max_length=20)
	author = models.ForeignKey(User, on_delete=models.CASCADE)


	def __str__(self):
		return self.firstname



	def get_absolute_url(self):
		return reverse('post-detail', kwargs={'pk': self.pk})